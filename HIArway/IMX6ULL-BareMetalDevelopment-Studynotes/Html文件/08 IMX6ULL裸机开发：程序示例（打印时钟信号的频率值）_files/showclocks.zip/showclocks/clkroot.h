#include "common.h"

void setup_arm_podf(u32 podf);
u32 get_arm_clk_root(void);
u32 get_ahb_clk_root(void);
u32 get_ipg_clk_root(void);
u32 get_axi_clk_root(void);
u32 get_fabric_mmdc_clk_root(void);
