#ifndef PLL_H
#define PLL_H

#include "common.h"

#define CKIH    24000000

typedef enum {
    ARM_PLL,
    USB1_PLL,
    USB2_PLL,
    SYS_PLL,
    AUDIO_PLL,
    VIDEO_PLL,
    ENET_PLL
} pll_e;

typedef enum {
    PFD0 = 0,
    PFD1,
    PFD2,
    PFD3
} pfd_e;

#define PFD_SHIFT(pfd)          (pfd*8)
#define PFD_MASK(pfd)           (0xFF<<PFD_SHIFT(pfd))
#define PFD_GATE_MASK(pfd)      (0x80<<PFD_SHIFT(pfd))
#define PFD_STABLE_MASK(pfd)    (0x40<<PFD_SHIFT(pfd))
#define PFD_FRAC_MASK(pfd)      (0x3F<<PFD_SHIFT(pfd))
#define PFD_FRAC_VALUE(value, pfd)      ((value>>PFD_SHIFT(pfd)) & 0x3F)

/* general definitions */
/*该寄存器为Analog ARM PLL control Register(CCM_ANALOG_PLL_ARMn)，用于控制锁相环电路*/
#define LOCK_MASK       (1u<<31) //将1左移31位，使得ARM_PLL锁定
#define BYPASS_MASK     (1u<<16) //处于Bypass模式时，源时钟信号不经过PLL放大，由路径2直接输出
#define ENABLE_MASK     (1u<<13) //开启时钟输出
#define POWERDOWN_MASK  (1u<<12) //关掉锁相环


/**********************************************************************
 * 函数名称： set_pll
 * 功能描述： 设置PLL的倍频参数并等待其进入锁定状态
 * 输入参数： pll: 指定PLL的标识，div: PLL的倍频参数
 * 输出参数： 无
 ***********************************************************************/
void set_pll(pll_e pll, u32 div);
/**********************************************************************
 * 函数名称： get_pll
 * 功能描述： 获取PLL的输出频率
 * 输入参数： pll: 指定PLL的标识
 * 输出参数： 无
 * 返 回 值： PLL的输出频率
 ***********************************************************************/
u32 get_pll(pll_e pll);
/**********************************************************************
 * 函数名称： set_pll_pfd
 * 功能描述： 设置SYS_PLL或USB1_PLL的PFD状态和分频参数
 * 输入参数： pll: 指定PLL的标识，pfd: 指定PFD的编号，gate: 是否屏蔽该PFD的输出，frac: PFD的分频参数
 * 输出参数： 无
 * 返 回 值： 无
 ***********************************************************************/
void set_pll_pfd(pll_e pll, pfd_e pfd, int gate, u32 frac);
/**********************************************************************
 * 函数名称： get_pll_pfd
 * 功能描述： 获取SYS_PLL或USB1_PLL的PFD输出频率
 * 输入参数： pll: 指定PLL的标识，pfd: 指定PFD的编号
 * 输出参数： 无
 * 返 回 值： 无
 ***********************************************************************/
u32 get_pll_pfd(pll_e pll, pfd_e pfd);

#endif  /* PLL_H */
