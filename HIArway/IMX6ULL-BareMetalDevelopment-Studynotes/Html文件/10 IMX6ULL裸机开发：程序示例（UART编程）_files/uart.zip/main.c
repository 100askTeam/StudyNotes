#include "uart.h"


void delay(volatile int d)
{
	while(d--);
}

int main(void)
{
	char c;
	uart_init();
	while(1)
	{
		c=getchar();
		putchar(c);
		putchar(c+1);
		
	}

	return 0;
}

