
#ifndef   __LED_H__
#define   __LED_H__

#include "common.h"

void led_gpio_init(void);
void led_ctl(int on);

#endif

