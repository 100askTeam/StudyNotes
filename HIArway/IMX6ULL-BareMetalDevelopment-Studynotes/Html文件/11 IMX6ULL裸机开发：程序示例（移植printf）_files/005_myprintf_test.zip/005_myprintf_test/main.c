#include "my_printf.h"
#include "uart.h"
int  main()
{	Uart_Init();
	my_printf_test();			
	return 0;
}
		  			 		  						  					  				 	   		  	  	 	  