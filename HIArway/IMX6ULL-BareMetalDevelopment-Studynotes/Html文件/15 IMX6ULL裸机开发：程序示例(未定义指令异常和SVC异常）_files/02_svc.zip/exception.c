

void do_undefined_c(unsigned int lr)
{
	puts("do_undefined_c\n\r");
}

void do_svc_c(unsigned int lr)
{
	puts("do_svc_c\n\r");
}


